Taller de OSM/JOSM + ImpOSM + TileMill de las VI Jornadas de SIG Libre de Girona.

Directorios:

* datos: datos del taller
* presen: presentaciones
* html: contenidos del taller 

Se recomienda abrir el archivo html/index.html

Taller Josm + ImpOSM + Tilemill por Pedro-Juan Ferrer Matoses se encuentra bajo una Licencia Creative Commons Atribución-CompartirIgual 3.0 Unported .
