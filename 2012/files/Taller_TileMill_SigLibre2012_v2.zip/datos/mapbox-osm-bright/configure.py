#!/usr/bin/env python

from collections import defaultdict
config = defaultdict(defaultdict)

config["importer"] = "imposm" # either 'imposm' or 'osm2pgsql'

# The name given to the style. This is the name it will have in the TileMill
# project list, and a sanitized version will be used as the directory name
# in which the project is stored
config["name"] = "OSM Bright Universitat Girona"

# The path to your MapBox projects directory. In Windows, this defaults to
# %UserProfile%\MapBox\project ; in Mac & Ubuntu it's ~/Documents/MapBox/project
config["path"] = "/home/jornadas/Documents/MapBox/project/"

# PostGIS connection setup
# Leave empty for Mapnik defaults. The only required parameter is dbname.
config["postgis"]["host"]     = "localhost"
config["postgis"]["port"]     = "5432"
config["postgis"]["dbname"]   = "osm"
config["postgis"]["user"]     = "osm"
config["postgis"]["password"] = "osm"

# Increase performance if you are only rendering a particular area by
# specifying a bounding box to restrict queries. Format is "XMIN,YMIN,XMAX,YMAX"
# in the same units as the database (probably spherical mercator meters). The
# whole world is "-20037508.34 -20037508.34 20037508.34 20037508.34".
# Leave blank to let Mapnik estimate.
config["postgis"]["extent"] = "-20037508.34 -20037508.34 20037508.34 20037508.34"

# Land shapefiles required for the style. If you have already downloaded
# these or wish to use different versions, specify their paths here.
# OSM land shapefiles from MapBox are indexed for Mapnik and have blatant 
# errors corrected (eg triangles along the 180 E/W line), but are updated
# infrequently. The latest versions can be downloaded from osm.org:
# - http://tile.openstreetmap.org/processed_p.tar.bz2
# - http://tile.openstreetmap.org/shoreline_300.tar.bz2
config["processed_p"] = "http://tilemill-data.s3.amazonaws.com/osm/coastline-good.zip"
config["shoreline_300"] = "http://tilemill-data.s3.amazonaws.com/osm/shoreline_300.zip"
