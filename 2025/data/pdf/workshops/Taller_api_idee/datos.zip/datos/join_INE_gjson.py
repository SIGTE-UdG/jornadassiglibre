import json

def load_json_file(path):
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)

def load_geojson(path):
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_geojson(data, path):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def extract_code(entry, match_variable):
    for meta in entry.get("MetaData", []):
        if meta.get("T3_Variable") == match_variable:
            return meta.get("Codigo")
    return None

def join_multiple_jsons_to_geojson(json_sources, geojson_data, geojson_key):
    for source in json_sources:
        json_data = load_json_file(source["file"])
        match_variable = source["match_variable"]
        property_name = source["geojson_property_name"]

        code_to_value = {}
        for entry in json_data:
            code = extract_code(entry, match_variable)
            value = entry.get("Data", [{}])[0].get("Valor")
            if code and value is not None:
                code_to_value[code] = value

        for feature in geojson_data.get("features", []):
            feature_code = feature.get("properties", {}).get(geojson_key)
            if feature_code in code_to_value:
                feature["properties"][property_name] = code_to_value[feature_code]

    return geojson_data

# ============================
# CONFIGURACIÓN DEL USUARIO
# ============================

json_sources = [
    {
        "file": "0_INE_Paro.json",
        "match_variable": "Provincias",
        "geojson_property_name": "Paro"
    },
    {
        "file": "0_INE_poblacionProvincias.json",
        "match_variable": "Provincias",
        "geojson_property_name": "Poblacion"
    }
]

geojson_input = "UA.geojson"
geojson_output = "UA_join.geojson"
geojson_key = "cod_0101"

# ============================
# EJECUCIÓN
# ============================

geojson_data = load_geojson(geojson_input)
updated_geojson = join_multiple_jsons_to_geojson(json_sources, geojson_data, geojson_key)
save_geojson(updated_geojson, geojson_output)

print(f"Join completado. GeoJSON actualizado guardado en '{geojson_output}'.")
